* pty4j - Java PTY implementation - https://github.com/consulo/pty4j
* purejavacomm - we use forked version that fixes JNA and YourKit Profiler incompatibility - https://github.com/consulo/purejavacomm
* libwinpty.dll and winpty-agent.exe - Windows PTY native implementation used by pty4j, we use forked version from https://github.com/consulo/winpty